package com.hr.controller;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Slf4j
public class TestController {

//    @GetMapping("/401")
//    public String error401Test(){
//        log.info("error401Test 접속");
//        return "originSource/401";
//    }
//    @GetMapping("/404")
//    public String error404Test(){
//        log.info("error404Test 접속");
//        return "originSource/401";
//    }
//
//    @GetMapping("/500")
//    public String error500Test() {
//        log.info("error500Test 접속");
//        return "originSource/401";
//    }
    @GetMapping("/chart")
    public String chartTest(){
        log.info("chartTest 접속");
        return "originSource/charts";
    }
//    @GetMapping("/login")
//    public String loginTest(){
//        log.info("loginTest 접속");
//        return "originSource/login";
//    }
//    @GetMapping("/password")
//    public String passwordTest(){
//        log.info("passwordTest 접속");
//        return "originSource/password";
//    }
//    @GetMapping("/register")
//    public String registerTest(){
//        log.info("registerTest 접속");
//        return "originSource/register";
//    }
    @GetMapping("/table")
    public String tableTest(){
        log.info("tableTest 접속");
        return "originSource/tables";
    }

    @GetMapping("/maundy")
    public String maundyTest(){
        log.info("tableTest 접속");
        return "originSource/maundy_index";
    }

    @GetMapping("/squad")
    public String squadTest(){
        log.info("tableTest 접속");
        return "originSource/squad_index";
    }

    @GetMapping("/maxim")
    public String maximTest(){
        log.info("tableTest 접속");
        return "originSource/maxim_index";
    }



}
