package com.hr.domain;

import lombok.*;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Position2 {
    String position;
}
