package com.hr.domain;

import lombok.*;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class DesignWaitingListMember {
    int dw_seq;
    int m_num;
}
